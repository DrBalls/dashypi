#!/bin/bash
echo -n 0 > /sys/class/backlight/rpi_backlight/bl_power
