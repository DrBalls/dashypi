#!/bin/bash
echo -n 1 > /sys/class/backlight/rpi_backlight/bl_power
